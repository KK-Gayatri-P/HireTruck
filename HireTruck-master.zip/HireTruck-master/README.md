# HireTruck
HireTruck a simple prototype for demonstrate the Web Application in Gujarat Industrial Hackathon

This is a simple Web application to Represent the Prototype of our system in Gujarat Industruial Hackathon
  have a some of the cool tools like a
    - Php mailer
    - reCAPTCHA
    - Cronejob
    - Many more
   
    This web app is written using a 
    - php-POP version 7.2
    - MySQL version 5.1
    - Apache 5.*
    - manged by XAMP server 127.0.0.1 version 3.2.2 (Stable)
    
    it's just a prototype if you want to setup it on your pc than use GIT or download the following zip
    after that open mySQL and import the Database file using Import in PhpMyadmin.
    after installation run root folder which is HireTruck or load index.php 
    
    #following requirement need to satisfied before Use
    1) Generate Recaptcha using : https://www.google.com/recaptcha/admin/create
    2) Php Mailer : https://github.com/PHPMailer/PHPMailer
    3) Paytm Payment Gateway : https://dashboard.paytm.com/next/apikeys
    4) Way2Sms : https://www.way2sms.com
    
    #That's it You'll setup!!
    
    #Collaborator:
    1: Parmar Viral : https://about.me/viralparmar
    2: Shah Prince : https://about.me/prince_shah
    3: Joshi Ridham : https://rjsquare561299.wixsite.com/tech-rjj
    4: K.K. Gayatripriyadarsini : 
    5: Kaneria Kesha: 
