<?php
 $con=mysqli_connect("localhost","root","","hire_truck_demo");

 if($con)
 {
	 //echo "successfully";
 }

?>
